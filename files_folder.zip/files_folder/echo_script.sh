#!/bin/bash

echo "Script executed!"
