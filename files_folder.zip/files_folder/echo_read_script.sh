#!/bin/bash

echo "Enter a number"
read number
echo "Your number was $number"
